﻿const base = {
    url : "http://localhost:8080/springboot06pr7/"
}
export default base
